# -*- coding: utf-8 -*-
"""
محرك التحميل:
 1) vxtwitter API (سريع، مجاني، بدون تسجيل) — يستخرج رابط الفيديو المباشر.
 2) yt-dlp كخطة بديلة + خيارات جودة/صوت (يحتاج ffmpeg للصوت فقط).
"""
import asyncio
import os
import re
import shutil
import tempfile
import uuid
from dataclasses import dataclass, field
from typing import List, Optional

import httpx

import config

UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
      "(KHTML, like Gecko) Chrome/124.0 Safari/537.36")
TIMEOUT = httpx.Timeout(25.0, connect=15.0)

# منع تحميل ملفات ضخمة جداً
MAX_BYTES = config.MAX_FILE_MB * 1024 * 1024


@dataclass
class Media:
    url: str
    kind: str = "video"        # video | gif | image
    width: int = 0
    height: int = 0
    duration: int = 0          # ثوانٍ
    thumbnail: str = ""
    text: str = ""
    author: str = ""
    path: str = ""             # يُملأ بعد التحميل
    size: int = 0


@dataclass
class FetchResult:
    media: List[Media] = field(default_factory=list)
    error: str = ""
    source: str = ""           # vxtwitter | yt-dlp

    @property
    def ok(self) -> bool:
        return bool(self.media) and not self.error


# ─── محلل الروابط ───────────────────────────────────────────
def _parse_tweet(url: str):
    """يُعيد (user, status_id) من رابط x/twitter."""
    m = re.search(r"(?:twitter|x)\.com/(?:[^/?#]+)/status/(\d+)", url, re.IGNORECASE)
    if not m:
        return None
    user = url.split(".com/")[-1].split("/status/")[0].strip()
    return user, m.group(1)


async def resolve_short(url: str) -> Optional[str]:
    """حل روابط t.co المختصرة إلى الرابط الكامل."""
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT, follow_redirects=False) as c:
            r = await c.head(url, headers={"User-Agent": UA})
            loc = r.headers.get("location", "")
            if not loc and r.status_code == 200:
                # بعض الخوادم ترفض HEAD → GET
                r2 = await c.get(url, headers={"User-Agent": UA}, follow_redirects=False)
                loc = r2.headers.get("location", "")
            if loc and ("x.com" in loc or "twitter.com" in loc):
                return loc
    except Exception:
        pass
    return None


# ─── المحاولة الأولى: vxtwitter ─────────────────────────────
async def _vxtwitter(user: str, status_id: str) -> Optional[FetchResult]:
    api = f"https://api.vxtwitter.com/{user}/{status_id}"
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT) as c:
            r = await c.get(api, headers={"User-Agent": UA})
            if r.status_code != 200:
                return None
            data = r.json()
    except Exception as e:
        return FetchResult(error=f"vxtwitter: {e}")

    if data.get("text") == "Tweet not found" or "media" not in data:
        return FetchResult(error="no media", source="vxtwitter")

    media = data["media"] or {}
    kind = (media.get("type") or "video").lower()   # video | gif | image
    texts = data.get("text", "")
    author = (data.get("user_name") or "user")
    items: List[Media] = []

    if kind == "image" and "media_extended" in data:
        for m in data["media_extended"]:
            if isinstance(m, dict) and m.get("url"):
                items.append(Media(url=m["url"], kind="image",
                                   width=m.get("width", 0), height=m.get("height", 0),
                                   thumbnail=m.get("thumbnail_url", ""), text=texts, author=author))
    elif media.get("url"):
        items.append(Media(url=media["url"], kind=kind,
                           width=media.get("width", 0), height=media.get("height", 0),
                           duration=media.get("duration", 0) or 0,
                           thumbnail=media.get("thumbnail_url", ""), text=texts, author=author))
    # ألبومات (تغريدات فيها عدة مقاطع/صور)
    for m in data.get("media_extended", []) or []:
        if isinstance(m, dict) and m.get("url") and not any(x.url == m["url"] for x in items):
            items.append(Media(url=m["url"], kind=(m.get("type") or kind).lower(),
                               width=m.get("width", 0), height=m.get("height", 0),
                               duration=m.get("duration", 0) or 0,
                               text=texts, author=author))

    if not items:
        return FetchResult(error="no media", source="vxtwitter")
    return FetchResult(media=items, source="vxtwitter")


# ─── المحاولة الثانية: yt-dlp ───────────────────────────────
def _ytdlp_extract_sync(url: str, want_audio: bool = False):
    """تشغيل yt-dlp في مسار منفصل (كتلة) — أسترجع القوائم والفورمات."""
    import yt_dlp

    opts = {
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True,
        "skip_download": True,
        "socket_timeout": 20,
    }
    if config.COOKIE_FILE and os.path.exists(config.COOKIE_FILE):
        opts["cookiefile"] = config.COOKIE_FILE
    out = {}
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            info = ydl.extract_info(url, download=False)
            out["info"] = info
    except Exception as e:
        out["error"] = str(e)
    return out


async def _ytdlp(url: str, want_audio: bool = False) -> Optional[FetchResult]:
    try:
        res = await asyncio.to_thread(_ytdlp_extract_sync, url, want_audio)
    except Exception as e:
        return FetchResult(error=f"yt-dlp thread: {e}")

    if res.get("error") or not res.get("info"):
        return FetchResult(error=res.get("error", "yt-dlp failed"), source="yt-dlp")

    info = res["info"]
    if info.get("_type") == "playlist":  # أمان
        entries = [e for e in (info.get("entries") or []) if e]
        if not entries:
            return FetchResult(error="empty playlist", source="yt-dlp")
        info = entries[0]

    if want_audio:
        formats = info.get("formats") or []
        audio_best = max([f for f in formats if f.get("acodec") not in (None, "none") and f.get("vcodec") in (None, "none")],
                         key=lambda f: f.get("tbr") or 0, default=None) or \
                     max([f for f in formats if f.get("acodec") not in (None, "none")],
                         key=lambda f: f.get("tbr") or 0, default=None)
        if audio_best:
            return FetchResult(media=[Media(url=audio_best["url"], kind="audio",
                                            text=info.get("description") or "",
                                            author=info.get("uploader") or "")],
                               source="yt-dlp")
        return FetchResult(error="no audio format", source="yt-dlp")

    formats = info.get("formats") or []
    # نفضّل مقاطع mp4 متكاملة (فيديو+صوت) بلا ffmpeg
    progressive = [f for f in formats
                   if f.get("vcodec") not in (None, "none")
                   and f.get("acodec") not in (None, "none")
                   and f.get("ext") in ("mp4", "m4a", "mov", "webm")]
    best = None
    if progressive:
        best = max(progressive, key=lambda f: (f.get("height") or 0, f.get("tbr") or 0))
    if not best:
        v = max([f for f in formats if f.get("vcodec") not in (None, "none")],
                key=lambda f: (f.get("height") or 0, f.get("tbr") or 0), default=None)
        a = max([f for f in formats if f.get("acodec") not in (None, "none")],
                key=lambda f: f.get("tbr") or 0, default=None)
        # بدون ffmpeg لا نستطيع الدمج → نرسل الصوت مع الفيديو؟ نعم: نرسل الفيديو منفرداً
        best = v
    if not best:
        return FetchResult(error="no video format", source="yt-dlp")

    return FetchResult(
        media=[Media(url=best["url"], kind="video",
                     width=best.get("width") or 0, height=best.get("height") or 0,
                     duration=info.get("duration") or 0,
                     thumbnail=info.get("thumbnail") or "",
                     text=info.get("description") or "",
                     author=info.get("uploader") or "")],
        source="yt-dlp")


# ─── الواجهة العامة ─────────────────────────────────────────
def _ext(url: str) -> str:
    parts = url.split("?")[0].split(".")[-1].lower()
    return parts if len(parts) <= 5 else "mp4"


async def fetch(url: str, want_audio: bool = False) -> FetchResult:
    """الحصول على وسائط التغريدة (بدون تنزيل الملف الفعلي بعد)."""
    short = None
    if url.startswith("http") and "t.co/" in url:
        short = url
        resolved = await resolve_short(url)
        if resolved:
            url = resolved
    if url.startswith("http"):
        parsed = _parse_tweet(url)
        if parsed:
            user, sid = parsed
            r = await _vxtwitter(user, sid)
            if r and r.ok:
                return r
        r = await _ytdlp(url, want_audio)
        return r
    return FetchResult(error="bad url")


async def download(media: Media, quality: str = "") -> Media:
    """تنزيل الملف إلى قرص مؤقت مع توقّف عند تجاوز الحجم الأقصى."""
    ext = _ext(media.url)
    path = os.path.join(tempfile.gettempdir(), f"xdl_{uuid.uuid4().hex[:10]}.{ext}")
    headers = {"User-Agent": UA}
    if "pbs.twimg.com" in media.url or "video.twimg.com" in media.url:
        headers["Referer"] = "https://x.com/"

    tmp = path + ".part"
    size = 0
    try:
        async with httpx.AsyncClient(timeout=TIMEOUT, follow_redirects=True) as c:
            async with c.stream("GET", media.url, headers=headers) as r:
                r.raise_for_status()
                with open(tmp, "wb") as f:
                    async for chunk in r.aiter_bytes(256 * 1024):
                        size += len(chunk)
                        if size > MAX_BYTES:
                            raise OverflowError()
                        f.write(chunk)
        os.replace(tmp, path)
    except OverflowError:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise
    except Exception as e:
        try:
            os.remove(tmp)
        except OSError:
            pass
        raise RuntimeError(str(e))

    media.path = path
    media.size = size
    return media


def ffmpeg_available() -> bool:
    return shutil.which("ffmpeg") is not None
