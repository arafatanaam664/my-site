# -*- coding: utf-8 -*-
"""أدوات مساعدة: استخراج الروابط، النصوص، التنسيقات."""
import re

import config

# أنماط روابط تويتر/X
TWEET_RE = re.compile(
    r"(?:https?://)?(?:www\.)?(?:mobile\.|m\.)?(?:twitter|x)\.com/"
    r"(?:[^/?#\s]+/status/|i/web/status/)(\d+)",
    re.IGNORECASE,
)
# رابط مختصر t.co
TCO_RE = re.compile(r"(?:https?://)?t\.co/[A-Za-z0-9]{6,}", re.IGNORECASE)
# أي رابط http(s) عادي
ANY_URL_RE = re.compile(r"https?://[^\s<>\"']+", re.IGNORECASE)

TWITTER_ID_RE = re.compile(r"(?:twitter|x)\.com/(?:[^/]+)/status/(\d+)", re.IGNORECASE)


def find_tweet_url(text: str):
    """يبحث عن أول رابط تغريدة (مباشر أو مختصر) في النص.
    يُرجع (نوع, قيمة): ('tweet', id) أو ('short', url) أو None."""
    m = TWEET_RE.search(text or "")
    if m:
        return "tweet", m.group(1)
    m = TCO_RE.search(text or "")
    if m:
        return "short", m.group(0)
    m = ANY_URL_RE.search(text or "")
    if m:
        url = m.group(0).rstrip(").,;")
        if "twitter.com" in url or "x.com" in url:
            return "tweet", url
        return None
    return None


def build_tweet_url(user: str, status_id: str) -> str:
    user = (user or "i").strip("/").lstrip("@")
    return f"https://x.com/{user}/status/{status_id}"


def human_size(num: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if num < 1024 or unit == "GB":
            return f"{num:.0f} {unit}" if unit == "B" else f"{num:.1f} {unit}"
        num /= 1024


def human_time(ts: int) -> str:
    import datetime
    if not ts:
        return "—"
    return datetime.datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M")


def clip(text: str, n: int = 40) -> str:
    text = (text or "").replace("\n", " ")
    return text if len(text) <= n else text[: n - 1] + "…"


def esc(text: str) -> str:
    """تعقيم النصوص (من التغريدات مثلاً) قبل وضعها في رسائل HTML — يمنع أخطاء التنسيق."""
    import html as _html
    return _html.escape(text or "")


# ─── الترجمة (عربي / إنجليزي) ───────────────────────────────
T = {
    "ar": {
        "welcome": ("👋 أهلاً {name}!\n"
                    "أنا <b>XDL PRO</b> — بوت تحميل فيديوهات من <b>X (تويتر)</b> بجودة عالية.\n\n"
                    "📥 <b>طريقة الاستخدام:</b>\n"
                    "فقط انسخ رابط التغريدة التي فيها الفيديو وأرسله لي هنا، وسأحضر لك الفيديو فوراً.\n\n"
                    "🎁 <b>ميزاتي:</b>\n"
                    "• تحميل فيديو/جيف بصيغة MP4 بأفضل جودة\n"
                    "• تحويل الفيديو إلى صوت MP3\n"
                    "• نظام دعوة الأصدقاء (إحالات) لترفع حدودك اليومية\n"
                    "• يعمل في الكروبات أيضاً (اعمل منشن لي مع الرابط)"),
        "help": ("🆘 <b>المساعدة</b>\n\n"
                 "1️⃣ انسخ رابط تغريدة X تحتوي فيديو\n"
                 "2️⃣ أرسله هنا (أو اعمل منشن لي داخل الكروب)\n"
                 "3️⃣ انتظر ثوانٍ وسيصلك الفيديو بأفضل جودة\n\n"
                 "📌 الأوامر المتاحة:\n"
                 "/start — التشغيل\n/help — المساعدة\n/id — معرفك\n"
                 "/referral — رابط دعوتك ومكافآتك\n/language — تغيير اللغة"),
        "not_a_tweet": "🤷‍♂️ هذا الرابط لا يبدو أنه تغريدة X فيها فيديو.\nأرسل رابط تغريدة مثل: <code>x.com/user/status/12345</code>",
        "join_first": ("🔒 <b>للاستمرار في استخدام البوت، اشترك في القنوات التالية:</b>\n\n{channels}\n\n"
                       "📌 بعد الاشتراك اضغط زر «تم — تحقق الآن»"),  # الأزرار خارج النص
        "checking": "✅ تم التحقق! اشتراكك مؤكد، تابع استخدام البوت.",
        "not_yet": "⚠️ لم تكتشف اشتراكك بعد — تأكد من الاشتراك في كل القنوات ثم اضغط «تحقق».",
        "no_download_media": "😅 لا يوجد فيديو أو مقطع قابل للتحميل في هذه التغريدة.",
        "processing": "⏳ جارٍ معالجة الرابط…",
        "downloading": "⬇️ جارٍ التحميل…",
        "sending": "📤 جارٍ الإرسال…",
        "done": "✅ تم التحميل بنجاح!",
        "size_too_big": "📦 الفيديو كبير جداً على تيليجرام (أكثر من {limit}MB).\nجرّب رابطاً آخر أو اطلب جودة أقل.",
        "error": "❌ حدث خطأ أثناء التحميل.\n{err}\n\nجرّب الرابط مرة أخرى بعد قليل، أو أرسله مثل: <code>x.com/user/status/12345</code>",
        "limited": "⚠️ وصلت للحد اليومي ({limit} تحميل/يوم).\n🎁 ارفع حدك بدعوة أصدقائك: /referral",
        "cooldown": "🐢 تمهل قليلاً… أعد المحاولة بعد {sec} ثانية.",
        "banned": "⛔ أنت محظور من استخدام البوت.",
        "your_id": "🆔 معرفك: <code>{id}</code>",
        "referral": ("🎁 <b>برنامج الدعوة</b>\n\n"
                     "🔗 رابطك الخاص:\n<code>{link}</code>\n\n"
                     "👥 أصدقاؤك المدعوون: <b>{count}</b>\n"
                     "⚡ مكافأة كل صديق: <b>+{bonus}</b> تحميل يومي (خفيف)\n\n"
                     "شارك الرابط في الكروبات والقنوات وسترفع حدودك!"),
        "choose_action": "🛠️ اختر العملية من الأزرار:",
        "audio_ready": "🎵 اختر: فيديو MP4 أم صوت MP3؟",
        "channel_sub_fail": "⚠️ تعذر التحقق من القناة {ch} — تأكد أن البوت مشرف فيها.",
        "updated_lang": "🌐 تم تغيير اللغة إلى العربية ✅",
        "broadcast_done": "📣 تم الإرسال إلى {ok} مستخدم (فشل: {fail})",
    },
    "en": {
        "welcome": ("👋 Hello {name}!\n"
                    "I'm <b>XDL PRO</b> — download videos from <b>X (Twitter)</b> in high quality.\n\n"
                    "📥 <b>How to use:</b>\n"
                    "Copy the tweet link with the video and send it here — I'll fetch it instantly.\n\n"
                    "🎁 <b>Features:</b>\n"
                    "• MP4 video/GIF in best quality\n"
                    "• Convert video to MP3 audio\n"
                    "• Referral program to raise your daily limit\n"
                    "• Works in groups too (mention me with the link)"),
        "help": ("🆘 <b>Help</b>\n\n"
                 "1️⃣ Copy an X tweet link containing a video\n"
                 "2️⃣ Send it here (or mention me in a group)\n"
                 "3️⃣ Wait a few seconds and get the video\n\n"
                 "📌 Commands:\n/start /help /id /referral /language"),
        "not_a_tweet": "🤷‍♂️ That link doesn't look like an X tweet with a video.\nSend something like: <code>x.com/user/status/12345</code>",
        "join_first": "🔒 <b>To continue using the bot, join the channels below first:</b>\n\n{channels}",
        "checking": "✅ Verified! You're subscribed. Enjoy.",
        "not_yet": "⚠️ Subscription not detected — make sure you joined all channels, then tap Verify.",
        "no_download_media": "😅 No downloadable video/GIF found in this tweet.",
        "processing": "⏳ Processing link…",
        "downloading": "⬇️ Downloading…",
        "sending": "📤 Sending…",
        "done": "✅ Done!",
        "size_too_big": "📦 Video too large for Telegram (>{limit}MB).\nTry another link or a lower quality.",
        "error": "❌ Download error.\n{err}\n\nTry again later, or send like: <code>x.com/user/status/12345</code>",
        "limited": "⚠️ Daily limit reached ({limit}/day).\n🎁 Raise it by inviting friends: /referral",
        "cooldown": "🐢 Slow down… retry in {sec}s.",
        "banned": "⛔ You are banned from using this bot.",
        "your_id": "🆔 Your ID: <code>{id}</code>",
        "referral": ("🎁 <b>Referral program</b>\n\n"
                     "🔗 Your link:\n<code>{link}</code>\n\n"
                     "👥 Friends joined: <b>{count}</b>\n"
                     "⚡ Reward per friend: <b>+{bonus}</b> daily downloads"),
        "choose_action": "🛠️ Choose an action:",
        "audio_ready": "🎵 Choose: MP4 video or MP3 audio?",
        "channel_sub_fail": "⚠️ Can't verify channel {ch} — make sure the bot is an admin there.",
        "updated_lang": "🌐 Language switched to English ✅",
        "broadcast_done": "📣 Sent to {ok} users (failed: {fail})",
    },
}


def tr(lang: str, key: str, **kw) -> str:
    s = T.get(lang, T["ar"]).get(key) or T["ar"][key]
    try:
        return s.format(**kw)
    except (KeyError, IndexError):
        return s
