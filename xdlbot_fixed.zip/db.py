# -*- coding: utf-8 -*-
"""
طبقة قاعدة البيانات — SQLite مدمجة (ملف واحد، بلا تكلفة، يعمل على أي استضافة).
ملاحظة: مؤمَّنة بقفل واحد لمزامنة العمليات — آمنة تماماً مع bot async.
"""
import sqlite3
import threading
import time
from typing import Any, Optional

import config

_conn: Optional[sqlite3.Connection] = None
_lock = threading.RLock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    user_id        INTEGER PRIMARY KEY,
    first_name     TEXT DEFAULT '',
    username       TEXT DEFAULT '',
    is_banned      INTEGER DEFAULT 0,
    lang           TEXT DEFAULT 'ar',
    referrer_id    INTEGER DEFAULT 0,
    total_downloads INTEGER DEFAULT 0,
    daily_count    INTEGER DEFAULT 0,
    daily_date     TEXT DEFAULT '',
    joined_at      INTEGER DEFAULT 0,
    last_active    INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS channels (
    chat_id   INTEGER PRIMARY KEY,
    title     TEXT DEFAULT '',
    username  TEXT DEFAULT '',
    added_by  INTEGER DEFAULT 0,
    added_at  INTEGER DEFAULT 0,
    active    INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS admins (
    user_id   INTEGER PRIMARY KEY,
    added_by  INTEGER DEFAULT 0,
    added_at  INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS downloads (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER DEFAULT 0,
    media_type TEXT DEFAULT 'video',
    quality    TEXT DEFAULT '',
    url        TEXT DEFAULT '',
    ok         INTEGER DEFAULT 1,
    created_at INTEGER DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_downloads_date ON downloads(created_at);
CREATE INDEX IF NOT EXISTS idx_users_active ON users(last_active);
"""


def init() -> None:
    global _conn
    with _lock:
        if _conn is not None:
            return
        _conn = sqlite3.connect(config.DB_PATH, check_same_thread=False)
        _conn.row_factory = sqlite3.Row
        _conn.execute("PRAGMA journal_mode=WAL;")
        _conn.executescript(SCHEMA)
        _conn.commit()


def _q(sql: str, params: tuple = ()) -> sqlite3.Cursor:
    with _lock:
        cur = _conn.execute(sql, params)
        _conn.commit()
        return cur


def _one(sql: str, params: tuple = ()) -> Optional[sqlite3.Row]:
    with _lock:
        return _conn.execute(sql, params).fetchone()


def _all(sql: str, params: tuple = ()) -> list:
    with _lock:
        return _conn.execute(sql, params).fetchall()


# ─── المستخدمون ──────────────────────────────────────────────
def today() -> str:
    return time.strftime("%Y-%m-%d")


def get_user(user_id: int) -> Optional[sqlite3.Row]:
    return _one("SELECT * FROM users WHERE user_id=?", (user_id,))


def save_user(user_id: int, first_name: str = "", username: str = "",
              referrer_id: int = 0) -> sqlite3.Row:
    """تسجيل/تحديث المستخدم — يُرجع صف المستخدم."""
    now = int(time.time())
    row = _one("SELECT * FROM users WHERE user_id=?", (user_id,))
    if row is None:
        _q("INSERT OR IGNORE INTO users (user_id, first_name, username, referrer_id, joined_at, last_active) "
           "VALUES (?,?,?,?,?,?)", (user_id, first_name, username, referrer_id, now, now))
    else:
        _q("UPDATE users SET first_name=?, username=?, last_active=? WHERE user_id=?",
           (first_name, username, now, user_id))
    return _one("SELECT * FROM users WHERE user_id=?", (user_id,))


def set_field(user_id: int, field: str, value: Any) -> None:
    if field not in ("lang", "daily_count", "total_downloads", "is_banned", "username", "first_name", "daily_date"):
        return
    _q(f"UPDATE users SET {field}=? WHERE user_id=?", (value, user_id))


def all_users(include_banned: bool = False) -> list:
    q = "SELECT * FROM users" + ("" if include_banned else " WHERE is_banned=0")
    return _all(q)


def count_users() -> int:
    return _one("SELECT COUNT(*) c FROM users")["c"]


def count_active_today() -> int:
    return _one("SELECT COUNT(*) c FROM users WHERE daily_date=?", (today(),))["c"]


def count_banned() -> int:
    return _one("SELECT COUNT(*) c FROM users WHERE is_banned=1")["c"]


def daily_used(user_id: int) -> int:
    row = _one("SELECT daily_count, daily_date FROM users WHERE user_id=?", (user_id,))
    if row is None:
        return 0
    if row["daily_date"] != today():
        set_field(user_id, "daily_count", 0)
        set_field(user_id, "daily_date", today())
        return 0
    return row["daily_count"] or 0


def use_daily(user_id: int) -> int:
    """احتساب عملية تحميل — يُرجع العدد المحدث."""
    used = daily_used(user_id)
    _q("UPDATE users SET daily_count=?, daily_date=?, total_downloads=total_downloads+1, last_active=? "
       "WHERE user_id=?", (used + 1, today(), int(time.time()), user_id))
    return used + 1


# ─── القنوات الإجبارية ──────────────────────────────────────
def add_channel(chat_id: int, title: str = "", username: str = "", added_by: int = 0) -> None:
    _q("INSERT OR REPLACE INTO channels (chat_id, title, username, added_by, added_at, active) "
       "VALUES (?,?,?,?,?,1)", (chat_id, title, username, added_by, int(time.time())))


def del_channel(chat_id: int) -> None:
    _q("DELETE FROM channels WHERE chat_id=?", (chat_id,))


def list_channels() -> list:
    return _all("SELECT * FROM channels WHERE active=1 ORDER BY added_at")


# ─── المشرفون الديناميكيون ──────────────────────────────────
def add_admin(user_id: int, added_by: int) -> None:
    _q("INSERT OR IGNORE INTO admins (user_id, added_by, added_at) VALUES (?,?,?)",
       (user_id, added_by, int(time.time())))


def del_admin(user_id: int) -> None:
    _q("DELETE FROM admins WHERE user_id=?", (user_id,))


def is_dynamic_admin(user_id: int) -> bool:
    return _one("SELECT 1 FROM admins WHERE user_id=?", (user_id,)) is not None


# ─── الإعدادات الديناميكية (قابلة للتعديل من اللوحة) ───────
def get_setting(key: str, default: str = "") -> str:
    row = _one("SELECT value FROM settings WHERE key=?", (key,))
    return row["value"] if row else default


def set_setting(key: str, value: str) -> None:
    _q("INSERT OR REPLACE INTO settings (key, value) VALUES (?,?)", (key, value))


# ─── سجل التحميلات ──────────────────────────────────────────
def log_download(user_id: int, media_type: str, quality: str, url: str, ok: bool = True) -> None:
    _q("INSERT INTO downloads (user_id, media_type, quality, url, ok, created_at) VALUES (?,?,?,?,?,?)",
       (user_id, media_type, quality, url, 1 if ok else 0, int(time.time())))


def recent_downloads(limit: int = 30) -> list:
    return _all("SELECT * FROM downloads ORDER BY id DESC LIMIT ?", (limit,))


def count_downloads_today() -> int:
    return _one("SELECT COUNT(*) c FROM downloads WHERE created_at>=? AND ok=1",
                (int(time.time()) - 86400,))["c"]


def count_downloads_total() -> int:
    return _one("SELECT COUNT(*) c FROM downloads WHERE ok=1")["c"]


# ─── نسخة احتياطية ──────────────────────────────────────────
def backup_path() -> str:
    """نسخة متسقة من قاعدة البيانات تُرسل للمشرف."""
    import shutil
    path = config.DB_PATH + ".bak"
    with _lock:
        shutil.copyfile(config.DB_PATH, path)
    return path


def export_csv_users(path: str) -> str:
    import csv
    rows = _all("SELECT user_id, first_name, username, joined_at, last_active, total_downloads FROM users")
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["user_id", "name", "username", "joined_at", "last_active", "downloads"])
        for r in rows:
            w.writerow([r["user_id"], r["first_name"], r["username"],
                        time.strftime("%Y-%m-%d", time.localtime(r["joined_at"])) if r["joined_at"] else "",
                        time.strftime("%Y-%m-%d", time.localtime(r["last_active"])) if r["last_active"] else "",
                        r["total_downloads"]])
    return path
