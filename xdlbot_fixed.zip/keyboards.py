# -*- coding: utf-8 -*-
"""أزرار لوحة المفاتيح (طرق مباشرة)."""
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

import config


def main_menu() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton("📥 المساعدة", callback_data="m:help"),
         InlineKeyboardButton("🎁 دعوة أصدقاء", callback_data="m:referral")],
        [InlineKeyboardButton("🆔 معرفي", callback_data="m:id"),
         InlineKeyboardButton("🌐 اللغة", callback_data="m:lang")],
        [InlineKeyboardButton("📢 قناة التحديثات", url=f"https://t.me/{config.AD_CHANNEL}")]
    ] if config.AD_CHANNEL else [
        [InlineKeyboardButton("📥 المساعدة", callback_data="m:help"),
         InlineKeyboardButton("🎁 دعوة أصدقاء", callback_data="m:referral")],
        [InlineKeyboardButton("🆔 معرفي", callback_data="m:id"),
         InlineKeyboardButton("🌐 اللغة", callback_data="m:lang")],
    ]
    if config.BOT_USERNAME:
        rows.append([InlineKeyboardButton("📤 مشاركة البوت", url=f"https://t.me/{config.BOT_USERNAME}")])
    return InlineKeyboardMarkup(rows)


def force_sub_channels(channels) -> InlineKeyboardMarkup:
    rows = []
    for ch in channels:
        if ch["username"]:
            rows.append([InlineKeyboardButton(f"📢 {ch['title'] or ch['username']}",
                                              url=f"https://t.me/{ch['username']}")])
        else:
            rows.append([InlineKeyboardButton(f"📢 {ch['title'] or ch['chat_id']}",
                                              url=f"https://t.me/{ch['chat_id']}")])
    rows.append([InlineKeyboardButton("✅ تم — تحقق الآن", callback_data="fs:check")])
    return InlineKeyboardMarkup(rows)


def quality_menu() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton("🎵 تحويل إلى صوت MP3", callback_data="dl:audio")],
        [InlineKeyboardButton("🔁 إعادة التحميل", callback_data="dl:again")],
        [InlineKeyboardButton("❌ إلغاء", callback_data="dl:cancel")],
    ]
    return InlineKeyboardMarkup(rows)


def quality_menu_no_ffmpeg() -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton("🔁 إعادة التحميل", callback_data="dl:again")],
        [InlineKeyboardButton("❌ إلغاء", callback_data="dl:cancel")],
    ]
    return InlineKeyboardMarkup(rows)


def admin_menu(user_id: int) -> InlineKeyboardMarkup:
    rows = [
        [InlineKeyboardButton("📊 الإحصائيات", callback_data="adm:stats"),
         InlineKeyboardButton("📣 البث", callback_data="adm:bcast")],
        [InlineKeyboardButton("📢 القنوات الإجبارية", callback_data="adm:channels"),
         InlineKeyboardButton("⚙️ الإعدادات", callback_data="adm:settings")],
        [InlineKeyboardButton("👤 المستخدمون", callback_data="adm:users"),
         InlineKeyboardButton("🗂️ السجلات", callback_data="adm:logs")],
        [InlineKeyboardButton("👑 الإدارة", callback_data="adm:admins"),
         InlineKeyboardButton("💾 نسخة احتياطية", callback_data="adm:backup")],
        [InlineKeyboardButton("🔄 إعادة تشغيل", callback_data="adm:restart"),
         InlineKeyboardButton("❌ إغلاق", callback_data="adm:close")],
    ]
    return InlineKeyboardMarkup(rows)
