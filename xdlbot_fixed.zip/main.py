# -*- coding: utf-8 -*-
"""
نقطة دخول بديلة — بعض الاستضافات تشغّل main.py تلقائياً.
(نفس البوت — يمكن للاستضافة تشغيل bot.py أو main.py، كلاهما يعمل)
"""
import bot

if __name__ == "__main__":
    bot.main()
