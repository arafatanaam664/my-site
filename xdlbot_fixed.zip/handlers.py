# -*- coding: utf-8 -*-
"""معالجات المستخدم: البدء، المساعدة، اللغة، الإحالات، التحميل، الاشتراك الإجباري."""
import time

from telegram import Update, BotCommand
from telegram.constants import ChatAction, ParseMode
from telegram.error import BadRequest, Forbidden, TelegramError
from telegram.ext import (CallbackQueryHandler, CommandHandler, ContextTypes,
                          MessageHandler, filters)

import config
import db
import downloader
import keyboards
import utils

# تخزين مؤقت داخل الذاكرة: آخر استدعاء للمستخدم (منع السبام)
_last_call: dict = {}


def is_admin(user_id: int) -> bool:
    return user_id in config.ADMIN_IDS or db.is_dynamic_admin(user_id)


def _lang(user_id: int) -> str:
    row = db.get_user(user_id)
    return (row["lang"] if row else "ar") or "ar"


# ─── الاشتراك الإجباري ──────────────────────────────────────
async def check_subscription(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    """يُعيد True إذا اشترك المستخدم بكل القنوات (أو لم تُفعَّل القنوات)."""
    if db.get_setting("force_sub", "1") == "0":
        return True
    user_id = update.effective_user.id
    channels = db.list_channels()
    if not channels:
        return True

    missing = []
    for ch in channels:
        try:
            member = await context.bot.get_chat_member(ch["chat_id"], user_id)
            ok = member.status in ("member", "administrator", "creator")
            if not ok:
                missing.append(ch)
        except Forbidden:
            # البوت ليس مشرفاً بالقناة — نتحقق مرة واحدة ونسجل التحذير
            if ch["chat_id"] not in getattr(context.bot_data, "_fschwarn", set()):
                context.bot_data.setdefault("_fschwarn", set()).add(ch["chat_id"])
                for a in context.bot_data.get("_admins", []):
                    try:
                        await context.bot.send_message(a, f"⚠️ البوت ليس مشرفاً في القناة {ch['chat_id']} — تفعيل الاشتراك الإجباري معطل لهذه القناة.")
                    except Exception:
                        pass
            continue
        except TelegramError:
            continue

    if not missing:
        return True

    txt = utils.tr(_lang(user_id), "join_first",
                   channels="\n".join(f"• {utils.esc(ch['title'] or ch['username'] or str(ch['chat_id']))}" for ch in missing))
    try:
        await update.effective_message.reply_text(
            txt, reply_markup=keyboards.force_sub_channels(missing), parse_mode=ParseMode.HTML)
    except Exception:
        pass
    return False


# ─── /start ──────────────────────────────────────────────────
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user is None:
        return
    referrer = 0
    if context.args:
        arg = (context.args[0] or "").strip()
        if arg.isdigit():
            referrer = int(arg)
    row = db.save_user(user.id, user.first_name or "", user.username or "", referrer)
    if row is not None and referrer and referrer != user.id and not row["referrer_id"]:
        db.set_field(user.id, "referrer_id", referrer)

    if row and row["is_banned"]:
        await update.effective_message.reply_text(utils.tr(_lang(user.id), "banned"))
        return
    if not await check_subscription(update, context):
        return

    custom = db.get_setting("welcome", "")
    if custom:
        wtxt = custom.format(name=utils.clip(user.first_name or "صديقي", 30))
    else:
        wtxt = utils.tr(_lang(user.id), "welcome", name=utils.clip(user.first_name or "صديقي", 30))
    await update.effective_message.reply_text(wtxt, reply_markup=keyboards.main_menu(),
                                              parse_mode=ParseMode.HTML)


# ─── /help ───────────────────────────────────────────────────
async def help_m(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not await check_subscription(update, context):
        return
    await update.effective_message.reply_text(utils.tr(_lang(update.effective_user.id), "help"),
                                              parse_mode=ParseMode.HTML)


# ─── /id ─────────────────────────────────────────────────────
async def my_id(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.effective_message.reply_text(
        utils.tr(_lang(update.effective_user.id), "your_id", id=update.effective_user.id),
        parse_mode=ParseMode.HTML)


# ─── /referral ───────────────────────────────────────────────
async def referral(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user_id = update.effective_user.id
    link = f"https://t.me/{config.BOT_USERNAME}?start={user_id}" if config.BOT_USERNAME else "اضبط BOT_USERNAME في .env"
    count = db._one("SELECT COUNT(*) c FROM users WHERE referrer_id=?", (user_id,))["c"]
    bonus = db.get_setting("referral_bonus", str(config.DAILY_LIMIT // 3 or 5))
    await update.effective_message.reply_text(
        utils.tr(_lang(user_id), "referral", link=link, count=count, bonus=bonus),
        parse_mode=ParseMode.HTML, disable_web_page_preview=True)


# ─── /language ───────────────────────────────────────────────
async def language(update: Update, context: ContextTypes.DEFAULT_TYPE):
    kb = keyboards.InlineKeyboardMarkup([
        [keyboards.InlineKeyboardButton("🇸🇦 العربية", callback_data="lang:ar"),
         keyboards.InlineKeyboardButton("🇬🇧 English", callback_data="lang:en")]
    ])
    await update.effective_message.reply_text("🌐 اختر لغتك / Choose your language:", reply_markup=kb)


# ─── قائمة أزرار البداية ─────────────────────────────────────
async def menu_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data or ""
    lang = _lang(q.from_user.id)
    if data == "m:help":
        await q.message.reply_text(utils.tr(lang, "help"), parse_mode=ParseMode.HTML)
    elif data == "m:referral":
        await referral(update, context)
    elif data == "m:id":
        await q.message.reply_text(utils.tr(lang, "your_id", id=q.from_user.id), parse_mode=ParseMode.HTML)
    elif data == "m:lang":
        kb = keyboards.InlineKeyboardMarkup([
            [keyboards.InlineKeyboardButton("🇸🇦 العربية", callback_data="lang:ar"),
             keyboards.InlineKeyboardButton("🇬🇧 English", callback_data="lang:en")]
        ])
        await q.message.reply_text("🌐 اختر لغتك / Choose your language:", reply_markup=kb)


# ─── الأزرار المباشرة ────────────────────────────────────────
async def lang_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data in ("lang:ar", "lang:en"):
        code = q.data.split(":")[1]
        db.set_field(q.from_user.id, "lang", code)
        await q.message.reply_text(utils.tr(code, "updated_lang"))


# ─── الفحص بعد الاشتراك ─────────────────────────────────────
async def fs_check_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if await check_subscription(update, context):
        try:
            await q.message.reply_text(utils.tr(_lang(q.from_user.id), "checking"))
        except Exception:
            pass
    else:
        try:
            await q.message.reply_text(utils.tr(_lang(q.from_user.id), "not_yet"))
        except Exception:
            pass


# ─── تنزيل الفيديو ───────────────────────────────────────────
async def _do_download(update: Update, context: ContextTypes.DEFAULT_TYPE, url: str, want_audio: bool = False):
    user = update.effective_user
    uid = user.id
    lang = _lang(uid)
    context.user_data["pending_url"] = url  # لإعادة التحميل أو الصوت من الأزرار
    row = db.get_user(uid)
    if row and row["is_banned"]:
        await update.effective_message.reply_text(utils.tr(lang, "banned"))
        return

    now = time.time()
    last = _last_call.get(uid, 0)
    if now - last < config.COOLDOWN_SEC:
        wait = int(config.COOLDOWN_SEC - (now - last)) + 1
        await update.effective_message.reply_text(utils.tr(lang, "cooldown", sec=wait))
        return
    _last_call[uid] = now

    if not await check_subscription(update, context):
        return

    limit = int(db.get_setting("daily_limit", str(config.DAILY_LIMIT)))
    use_count = db.daily_used(uid)
    # مكافأة الإحالات: كل صديق يرفع الحد قليلاً
    friends = db._one("SELECT COUNT(*) c FROM users WHERE referrer_id=?", (uid,))["c"]
    bonus = int(db.get_setting("referral_bonus", str(config.DAILY_LIMIT // 3 or 5)))
    limit += friends * bonus
    if use_count >= limit:
        await update.effective_message.reply_text(utils.tr(lang, "limited", limit=limit))
        return

    if want_audio and not downloader.ffmpeg_available():
        await update.effective_message.reply_text("⚠️ خاصية الصوت غير متاحة حالياً (ffmpeg غير مثبت على الخادم).")
        return

    msg = await update.effective_message.reply_text(utils.tr(lang, "processing"))
    await context.bot.send_chat_action(update.effective_chat.id, ChatAction.UPLOAD_VIDEO)

    result = await downloader.fetch(url, want_audio=want_audio)
    if not result.ok:
        await msg.edit_text(utils.tr(lang, "error", err=utils.clip(result.error or "unknown", 80)))
        db.log_download(uid, "video" if not want_audio else "audio", "", url, ok=False)
        return

    # تحويل صوت: نمرر الوسائط إلى yt-dlp لتنزيل الصوت
    if want_audio:
        await msg.edit_text(utils.tr(lang, "downloading"))
        try:
            picked = await _download_audio(result.media[0], url)
        except Exception as e:
            await msg.edit_text(utils.tr(lang, "error", err=utils.clip(str(e), 80)))
            return
        await _send_media(context, update, msg, picked, lang, is_audio=True)
        db.log_download(uid, "audio", "", url)
        db.use_daily(uid)
        return

    # فيديو/جيف/صور
    total = len(result.media)
    sent = 0
    for i, media in enumerate(result.media, 1):
        if total > 1:
            await msg.edit_text(f"{utils.tr(lang, 'downloading')} ({i}/{total})")
        else:
            await msg.edit_text(utils.tr(lang, "downloading"))
        try:
            await downloader.download(media)
        except OverflowError:
            await msg.edit_text(utils.tr(lang, "size_too_big", limit=config.MAX_FILE_MB))
            try:
                if media.path and media.path != "":  # تنظيف
                    import os
                    os.remove(media.path)
            except Exception:
                pass
            return
        except Exception as e:
            await msg.edit_text(utils.tr(lang, "error", err=utils.clip(str(e), 80)))
            return
        try:
            await _send_media(context, update, msg, media, lang)
            sent += 1
        except (BadRequest, Forbidden) as e:
            if "file is too big" in str(e).lower():
                await msg.edit_text(utils.tr(lang, "size_too_big", limit=config.MAX_FILE_MB))
                return
            await msg.edit_text(utils.tr(lang, "error", err=utils.clip(str(e), 80)))
            return

    db.use_daily(uid)
    db.log_download(uid, "video", f"{total} media", url)
    try:
        await msg.edit_text(f"✅ {sent} {utils.tr(lang, 'done')}")
    except Exception:
        pass


async def _download_audio(media: downloader.Media, tweet_url: str) -> downloader.Media:
    """تنزيل الصوت عبر yt-dlp/ffmpeg ثم إرجاع Media بمسار الملف."""
    import subprocess
    import tempfile, uuid, os

    out = os.path.join(tempfile.gettempdir(), f"xdl_{uuid.uuid4().hex[:10]}.mp3")
    cmd = ["yt-dlp", "-f", "bestaudio/best", "-x", "--audio-format", "mp3",
           "--audio-quality", "0", "--no-playlist", "-o", out, tweet_url]
    if config.COOKIE_FILE and os.path.exists(config.COOKIE_FILE):
        cmd.insert(1, f"--cookies={config.COOKIE_FILE}")
    proc = await asyncio_create_subprocess(cmd)
    if proc != 0:
        raise RuntimeError("yt-dlp audio failed")
    media.path = out
    media.kind = "audio"
    media.size = os.path.getsize(out) if os.path.exists(out) else 0
    return media


async def asyncio_create_subprocess(cmd):
    import asyncio
    proc = await asyncio.create_subprocess_exec(
        *cmd, stdout=asyncio.subprocess.DEVNULL, stderr=asyncio.subprocess.DEVNULL)
    return await proc.wait()


async def _send_media(context, update, progress_msg, media: downloader.Media, lang: str, is_audio: bool = False):
    chat_id = update.effective_chat.id
    bot = context.bot
    caption = utils.esc(utils.clip(media.text or "", 700))
    extra = db.get_setting("caption", "")
    if extra and extra != "-":
        caption = (caption + ("\n" if caption else "") + utils.esc(extra))[:1000]
    kb = keyboards.quality_menu() if downloader.ffmpeg_available() else keyboards.quality_menu_no_ffmpeg()

    if is_audio or media.kind == "audio":
        with open(media.path, "rb") as f:
            await bot.send_audio(chat_id, f, caption=f"🎵 {caption}" if caption else "🎵 MP3",
                                 title="XDL Audio")
    elif media.kind == "image":
        with open(media.path, "rb") as f:
            await bot.send_photo(chat_id, f, caption=caption or None,
                                 parse_mode=ParseMode.HTML)
    elif media.kind == "gif":
        with open(media.path, "rb") as f:
            await bot.send_animation(chat_id, f, caption=caption or None,
                                     parse_mode=ParseMode.HTML)
    else:
        with open(media.path, "rb") as f:
            await bot.send_video(chat_id, f, caption=caption or None,
                                 parse_mode=ParseMode.HTML, supports_streaming=True,
                                 duration=media.duration or None,
                                 width=media.width or None, height=media.height or None)
    # تنظيف الملف المؤقت بعد الإرسال
    import os
    try:
        if media.path:
            os.remove(media.path)
    except Exception:
        pass


# ─── رسالة نصية: التقاط الروابط ─────────────────────────────
async def on_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user is None or not update.effective_message:
        return
    # دعم الكروبات: لا نعمل إلا إذا عُمل منشن بالبوت
    if update.effective_chat.type not in ("private",):
        groups_on = db.get_setting("groups_mode", "1" if config.ALLOW_GROUPS else "0") == "1"
        if not groups_on:
            return
        me = context.bot.username.lower()
        text = (update.effective_message.text or "") + " " + (update.effective_message.caption or "")
        if f"@{me}" not in text.lower():
            return

    found = utils.find_tweet_url(update.effective_message.text or "")
    if not found:
        # نص عادي → لا نرد نصاً مزعجاً، إلا إذا كان الأمر من اللوحة
        return

    kind, value = found
    _last_call[update.effective_user.id] = 0  # لا كول داون على أول رابط
    if kind == "short":
        resolved = await downloader.resolve_short(value)
        url = resolved or value
    else:
        url = value

    if url.isdigit():
        # معرف فقط بدون مستخدم: نحتاج رابطاً كاملاً
        await update.effective_message.reply_text(
            utils.tr(_lang(update.effective_user.id), "not_a_tweet"))
        return

    await _do_download(update, context, url)


# ─── أزرار جودة التحميل ─────────────────────────────────────
async def dl_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    data = q.data or ""
    if data == "dl:cancel":
        try:
            await q.message.edit_text("❌ أُلغيت العملية.")
        except Exception:
            pass
        return
    # نخزّن الرابط في user_data عبر الزر الذي جاء قبله — نعيد الجلب من الرسالة الأصلية
    url = context.user_data.get("pending_url")
    if not url:
        await q.message.edit_text("⚠️ انتهت صلاحية العملية — أرسل الرابط مجدداً.")
        return
    if data == "dl:again":
        await _do_download(update, context, url, want_audio=False)
    elif data == "dl:audio":
        await _do_download(update, context, url, want_audio=True)


def register(app):
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("help", help_m))
    app.add_handler(CommandHandler("id", my_id))
    app.add_handler(CommandHandler("referral", referral))
    app.add_handler(CommandHandler("language", language))
    app.add_handler(CommandHandler("lang", language))
    app.add_handler(CallbackQueryHandler(menu_cb, pattern=r"^m:"))
    app.add_handler(CallbackQueryHandler(lang_cb, pattern=r"^lang:"))
    app.add_handler(CallbackQueryHandler(fs_check_cb, pattern=r"^fs:"))
    app.add_handler(CallbackQueryHandler(dl_cb, pattern=r"^dl:"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, on_text))
