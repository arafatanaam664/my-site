# -*- coding: utf-8 -*-
"""
XDL PRO — بوت تيليجرام لتحميل فيديوهات X (تويتر)
▸ قاعدة بيانات SQLite مدمجة        ▸ لوحة تحكم كاملة من تيليجرام
▸ اشتراك إجباري متعدد القنوات      ▸ نظام إحالات وحدود يومية
▸ خادم فحص صحة (Health) لإبقاء البوت حيّاً على الاستضافات المجانية

التشغيل:  python3 bot.py
"""
import asyncio
import logging
import threading
import time

from telegram import BotCommand, Update
from telegram.ext import Application, CommandHandler, ContextTypes

import admin
import config
import db
import handlers

logging.basicConfig(
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    level=logging.INFO,
)
log = logging.getLogger("xdlpro")

app: Application = None


# ─── قائمة الأوامر التي تظهر في ملف البوت (تحسين الملف الشخصي) ──
COMMANDS = [
    BotCommand("start", "🚀 تشغيل البوت / Start"),
    BotCommand("help", "🆘 المساعدة / Help"),
    BotCommand("id", "🆔 معرفك / Your ID"),
    BotCommand("referral", "🎁 رابط الدعوة / Referral"),
    BotCommand("language", "🌐 تغيير اللغة"),
    BotCommand("admin", "🛠️ لوحة التحكم (للمشرفين)"),
    BotCommand("stats", "📊 الإحصائيات (للمشرفين)"),
]


# ─── خادم فحص الصحة (لإبقاء الاستضافة المجانية مستيقظة) ──────
def run_health_server():
    from aiohttp import web

    async def health(request):
        return web.Response(text="ok")

    async def webhook_handler(request):
        if app is None:
            return web.Response(status=503)
        try:
            data = await request.json()
        except Exception:
            return web.Response(status=400)
        update = Update.de_json(data, app.bot)
        if update is not None:
            await app.update_queue.put(update)
        return web.Response(text="ok")

    async def handler(request):
        if request.method == "GET" and request.path == config.HEALTH_PATH:
            return await health(request)
        if request.method == "POST" and request.path == config.WEBHOOK_PATH:
            return await webhook_handler(request)
        return web.Response(text="xdl bot is running", status=200)

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    app_http = web.Application()
    app_http.router.add_route("*", "/", handler)
    app_http.router.add_route("*", "/health", handler)
    app_http.router.add_route("*", "/webhook", handler)
    try:
        web.run_app(app_http, host="0.0.0.0", port=config.PORT, print=None, loop=loop,
                    handle_signals=False)
    except Exception as e:
        # لو فشل ربط المنفذ (مثل Serv00 حيث المنافذ مقيدة) لا يتوقف البوت — نكتفي بالـ Polling
        log.warning("تعذر تشغيل خادم الصحة (غير حرج): %s", e)


def start_health_server() -> None:
    t = threading.Thread(target=run_health_server, daemon=True)
    t.start()
    log.info("Health server على المنفذ %s (مسار %s) — يُنبّه كل 5 دقائق لإبقاء الاستضافة حيّة", config.PORT, config.HEALTH_PATH)


# ─── نقطة البداية ────────────────────────────────────────────
def main():
    if not config.VALID:
        print(config.banner())
        print("❌ BOT_TOKEN و ADMIN_IDS ناقصان — انسخ .env.example إلى .env واملأهما.")
        raise SystemExit(1)

    global app
    print(config.banner())
    db.init()
    log.info("قاعدة البيانات جاهزة: %s", config.DB_PATH)

    app = Application.builder().token(config.BOT_TOKEN).build()
    app.bot_data["boot_time"] = int(time.time())
    app.bot_data["_admins"] = sorted(config.ADMIN_IDS)

    handlers.register(app)
    admin.register(app)

    # ضبط أوامر ملف البوت الشخصي تلقائياً + (اختياري) نسخ احتياطي دوري لقاعدة البيانات
    async def post_init(application):
        try:
            await application.bot.set_my_commands(COMMANDS)
            log.info("تم ضبط قائمة أوامر البوت (تظهر في ملفه الشخصي).")
        except Exception as e:
            log.warning("تعذر ضبط الأوامر: %s", e)
        if config.AUTO_BACKUP_HOURS > 0:
            application.create_task(auto_backup_loop(application))
            log.info("نسخ احتياطي تلقائي كل %s ساعة (للمشرفين).", config.AUTO_BACKUP_HOURS)

    app.post_init = post_init
    app.add_error_handler(error_handler)

    if config.HEALTH_ENABLED:
        start_health_server()
    else:
        log.info("خادم الصحة معطل (HEALTH_ENABLED=false)")

    if config.WEBHOOK_URL:
        # وضع الويب هوك (اختياري): يحتاج رابطاً عاماً HTTPS
        import aiohttp.web as webapp  # noqa
        url = config.WEBHOOK_URL.rstrip("/") + config.WEBHOOK_PATH
        log.info("وضع Webhook: %s", url)
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(_run_webhook(url))
    else:
        log.info("وضع التحديث المستمر (Polling) — ابدأ!")
        app.run_polling(allowed_updates=Update.ALL_TYPES, drop_pending_updates=False)


async def auto_backup_loop(application: Application) -> None:
    """يرسل نسخة من قاعدة البيانات للمشرفين كل X ساعة (يحمي من القرص المؤقت في الاستضافات المجانية)."""
    import db
    while True:
        await asyncio.sleep(config.AUTO_BACKUP_HOURS * 3600)
        try:
            path = db.backup_path()
            with open(path, "rb") as f:
                for adm in config.ADMIN_IDS:
                    try:
                        await application.bot.send_document(
                            adm, f, caption="💾 نسخة احتياطية تلقائية لقاعدة البيانات")
                    except Exception:
                        pass
            log.info("أُرسلت النسخة الاحتياطية التلقائية للمشرفين.")
        except Exception as e:
            log.warning("فشلت النسخة الاحتياطية التلقائية: %s", e)


async def _run_webhook(url: str):
    await app.initialize()
    await app.start()
    await app.bot.set_webhook(url=url, allowed_updates=Update.ALL_TYPES)
    log.info("Webhook جاهز: %s", url)
    await asyncio.Event().wait()


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    """معالج أخطاء عام: يسجل كل خطأ في السجل بدلاً من توقف صامت."""
    log.error("استثناء أثناء معالجة التحديث: %s", context.error, exc_info=context.error)
    try:
        if isinstance(update, Update) and update.effective_message:
            await update.effective_message.reply_text(
                "⚠️ حدث خطأ غير متوقع — أعد المحاولة، وإن تكرر فأبلغ المشرف.")
    except Exception:
        pass


if __name__ == "__main__":
    main()
