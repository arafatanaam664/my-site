# -*- coding: utf-8 -*-
"""
إعدادات البوت — تُقرأ من ملف .env (بجانب سكربت التشغيل) أو من متغيرات البيئة مباشرة.
لا تضع التوكن داخل الكود أبداً — ضعه في ملف .env فقط.
"""
import os

def _load_dotenv(path: str = ".env") -> None:
    """تحميل ملف .env إن وُجد (بدون مكتبات خارجية)."""
    if not os.path.exists(path):
        return
    with open(path, encoding="utf-8") as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'").strip())

_load_dotenv()

def _env(key: str, default: str = "") -> str:
    return os.getenv(key, default).strip()

def _env_int(key: str, default: int) -> int:
    try:
        return int(os.getenv(key, default))
    except (TypeError, ValueError):
        return default

def _env_bool(key: str, default: bool = False) -> bool:
    v = os.getenv(key, "").strip().lower()
    if not v:
        return default
    return v in ("1", "true", "yes", "on", "y")

# ─── الأساسيات ───────────────────────────────────────────────
BOT_TOKEN    = _env("BOT_TOKEN", "")                      # توكن البوت من @BotFather
ADMIN_IDS    = {int(x) for x in _env("ADMIN_IDS", "").replace(" ", "").split(",") if x.strip().isdigit()}
BOT_USERNAME = _env("BOT_USERNAME", "").lstrip("@")       # معرف البوت بدون @ (لأزرار المشاركة)
SUPPORT      = _env("SUPPORT", "")                        # حساب الدعم الفني (بدون @)
AD_CHANNEL   = _env("AD_CHANNEL", "")                     # قناة التحديثات التي تظهر في القائمة الرئيسية

# ─── قاعدة البيانات ──────────────────────────────────────────
DB_PATH = _env("DB_PATH", "xdlbot.db")                    # ملف SQLite — لا يحتاج سيرفر خارجي

# ─── حدود وسلوك ─────────────────────────────────────────────
DAILY_LIMIT   = _env_int("DAILY_LIMIT", 25)               # حد التحميل اليومي الافتراضي
MAX_FILE_MB   = _env_int("MAX_FILE_MB", 48)               # أقصى حجم ملف (حد تيليجرام 50MB)
COOLDOWN_SEC  = _env_int("COOLDOWN_SEC", 4)               # ثواني بين كل طلب من نفس المستخدم
ALLOW_GROUPS  = _env_bool("ALLOW_GROUPS", True)           # السماح بالتحميل داخل الكروبات (بالمنشن)
COOKIE_FILE   = _env("COOKIE_FILE", "")                   # مسار كوكيز يوتيوب-دي-إل الاختياري
LOG_CHANNEL   = _env("LOG_CHANNEL", "")                   # معرف قناة السجلات (اختياري)

# ─── الخادم (للإبقاء حيّاً على الاستضافات المجانية) ─────────
PORT         = _env_int("PORT", 8080)                     # منفذ فحص الصحة (تقريباً كل الاستضافات تشترطه)
HEALTH_ENABLED = _env_bool("HEALTH_ENABLED", True)        # أطفئه على Serv00 (المنافذ مقيدة هناك)
WEBHOOK_URL  = _env("WEBHOOK_URL", "")                    # لو فارغ = وضع التحديث المستمر (polling)
WEBHOOK_PATH = _env("WEBHOOK_PATH", "/webhook")
HEALTH_PATH  = _env("HEALTH_PATH", "/health")

# ─── نسخ احتياطي تلقائي لقاعدة البيانات ─────────────────────
# مهم للاستضافات التي يكون قرصها مؤقتاً (مثل Hugging Face Spaces):
# حدد عدد الساعات بين كل نسخة تُرسل للمشرفين (0 = إيقاف)
AUTO_BACKUP_HOURS = _env_int("AUTO_BACKUP_HOURS", 0)

# ─── تحققات سريعة عند بدء التشغيل ───────────────────────────
VALID = bool(BOT_TOKEN and ADMIN_IDS)

def banner() -> str:
    return (
        "╔════════════════════════════════════╗\n"
        "║   XDL PRO — بوت تحميل فيديوهات X    ║\n"
        "║   + قاعدة بيانات + لوحة تحكم        ║\n"
        "╚════════════════════════════════════╝"
    )
