# -*- coding: utf-8 -*-
"""
لوحة التحكم الكاملة من تيليجرام:
إحصائيات، بث، قنوات إجبارية، إعدادات، مستخدمون، سجلات، مشرفون، نسخ احتياطية، إعادة تشغيل.
كل شيء يعمل عبر أزرار — بدون أي موقع خارجي.
"""
import asyncio
import os
import sys
import time

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.constants import ParseMode
from telegram.ext import (CallbackQueryHandler, CommandHandler, ContextTypes,
                          MessageHandler, filters)

import config
import db
import keyboards
import utils
from handlers import is_admin

# حالات الانتظار في context.user_data["adm_state"]
ST_BROADCAST   = "bcast"        # بانتظار محتوى البث
ST_ADD_CHANNEL = "add_channel"  # بانتظار @القناة أو -100 أو تحويل
ST_DEL_CHANNEL = "del_channel"
ST_FIND_USER   = "find_user"
ST_ADD_ADMIN   = "add_admin"
ST_DEL_ADMIN   = "del_admin"
ST_SET_WELCOME = "set_welcome"
ST_SET_CAPTION = "set_caption"


def _admin_ids() -> set:
    return set(config.ADMIN_IDS) | {r["user_id"] for r in db._all("SELECT user_id FROM admins")}


# ─── /admin ──────────────────────────────────────────────────
async def admin_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    await update.effective_message.reply_text("🛠️ <b>لوحة التحكم</b> — اختر عملية:",
                                              reply_markup=keyboards.admin_menu(update.effective_user.id),
                                              parse_mode=ParseMode.HTML)


async def stats_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    await _stats(update, context)


async def _stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    total_u = db.count_users()
    today_u = db.count_active_today()
    banned = db.count_banned()
    dl_today = db.count_downloads_today()
    dl_total = db.count_downloads_total()
    ch = db.list_channels()
    txt = (
        "📊 <b>إحصائيات البوت</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        f"👥 إجمالي المستخدمين: <b>{total_u}</b>\n"
        f"🟢 نشطون اليوم: <b>{today_u}</b>\n"
        f"⛔ المحظورون: <b>{banned}</b>\n"
        f"⬇️ تحميلات اليوم: <b>{dl_today}</b>\n"
        f"📦 إجمالي التحميلات: <b>{dl_total}</b>\n"
        f"📢 قنوات إجبارية: <b>{len(ch)}</b>\n"
        "━━━━━━━━━━━━━━━━━━\n"
        "🖥️ وقت التشغيل المستمر: متاح عبر /status"
    )
    try:
        await update.effective_message.reply_text(txt, parse_mode=ParseMode.HTML)
    except AttributeError:
        await update.callback_query.message.reply_text(txt, parse_mode=ParseMode.HTML)


# ─── القائمة الرئيسية ────────────────────────────────────────
async def menu_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    uid = q.from_user.id
    if not is_admin(uid):
        await q.answer("ليس لديك صلاحية ⛔", show_alert=True)
        return
    data = q.data or ""

    if data == "adm:close":
        try:
            await q.message.edit_text("🔒 أُغلقت اللوحة.")
        except Exception:
            pass
    elif data == "adm:stats":
        txt = (
            "📊 <b>الإحصائيات</b>\n━━━━━━━━━━━━━━━━━━\n"
            f"👥 المستخدمون: <b>{db.count_users()}</b> | نشطون اليوم: <b>{db.count_active_today()}</b>\n"
            f"⛔ المحظورون: <b>{db.count_banned()}</b>\n"
            f"⬇️ تحميلات اليوم: <b>{db.count_downloads_today()}</b> | الإجمالي: <b>{db.count_downloads_total()}</b>\n"
            f"📢 القنوات: <b>{len(db.list_channels())}</b>"
        )
        await q.message.edit_text(txt, parse_mode=ParseMode.HTML)
    elif data == "adm:bcast":
        context.user_data["adm_state"] = ST_BROADCAST
        await q.message.edit_text(
            "📣 <b>البث الجماعي</b>\n\nأرسل الآن <b>الرسالة</b> التي تريد بثها للمستخدمين\n"
            "(نص / صورة / فيديو / توجيه رسالة) وسأريك معاينة للتأكيد.",
            parse_mode=ParseMode.HTML)
    elif data == "adm:channels":
        await _channels_menu(q)
    elif data == "adm:settings":
        await _settings_menu(q)
    elif data == "adm:users":
        context.user_data["adm_state"] = ST_FIND_USER
        await q.message.edit_text(
            "🔎 <b>البحث عن مستخدم</b>\n\nأرسل: معرف (ID) أو @username\nأو قم <b>بتحويل رسالة</b> من المستخدم نفسه.\n\nأو استخدم: /user &lt;id&gt;",
            parse_mode=ParseMode.HTML)
    elif data == "adm:logs":
        rows = db.recent_downloads(25)
        lines = [f"• {utils.human_time(r['created_at'])} | u{r['user_id']} | {r['media_type']} | {'✅' if r['ok'] else '❌'} | {utils.clip(r['url'], 30)}"
                 for r in rows]
        txt = "🗂️ <b>آخر التحميلات</b>\n" + ("\n".join(lines) if lines else "لا توجد بعد.")
        await q.message.edit_text(txt, parse_mode=ParseMode.HTML)
    elif data == "adm:admins":
        adm = _admin_ids()
        txt = "👑 <b>الإدارة</b>\n\n" + "\n".join(f"• <code>{a}</code>" for a in sorted(adm))
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("➕ إضافة مشرف", callback_data="adm:add_admin")],
            [InlineKeyboardButton("➖ حذف مشرف", callback_data="adm:del_admin")],
        ])
        await q.message.edit_text(txt, reply_markup=kb, parse_mode=ParseMode.HTML)
    elif data == "adm:add_admin":
        context.user_data["adm_state"] = ST_ADD_ADMIN
        await q.message.edit_text("👑 أرسل معرف المستخدم (ID) أو قم بتحويل رسالة منه لإضافته مشرفاً.")
    elif data == "adm:del_admin":
        context.user_data["adm_state"] = ST_DEL_ADMIN
        await q.message.edit_text("➖ أرسل معرف المستخدم (ID) الذي تريد إزالة صلاحياته.")
    elif data == "adm:backup":
        path = db.backup_path()
        try:
            with open(path, "rb") as f:
                await q.message.reply_document(f, caption="💾 نسخة قاعدة البيانات (SQLite)")
        except Exception as e:
            await q.message.reply_text(f"❌ تعذر النسخ: {e}")
        csvp = db.export_csv_users(os.path.join(os.path.dirname(path), "users.csv"))
        try:
            with open(csvp, "rb") as f:
                await q.message.reply_document(f, caption="👥 قائمة المستخدمين CSV")
        except Exception:
            pass
    elif data == "adm:restart":
        await q.message.edit_text("🔄 جارٍ إعادة تشغيل البوت…")
        await asyncio.sleep(1)
        os.execv(sys.executable, [sys.executable, os.path.abspath("bot.py")])
    elif data == "adm:set_welcome":
        context.user_data["adm_state"] = ST_SET_WELCOME
        await q.message.edit_text("💬 أرسل نص رسالة الترحيب الجديدة (HTML مدعوم).\n\nالحالية:\n" +
                                  db.get_setting("welcome", "غير محددة"))
    elif data == "adm:set_caption":
        context.user_data["adm_state"] = ST_SET_CAPTION
        await q.message.edit_text("🏷️ أرسل نص الكابشن الذي سيُضاف أسفل كل فيديو (اتركه فارغاً لإلغائه).")
    elif data == "adm:toggle_force":
        cur = db.get_setting("force_sub", "1")
        new = "0" if cur == "1" else "1"
        db.set_setting("force_sub", new)
        await _settings_menu(q)
    elif data == "adm:toggle_groups":
        cur = db.get_setting("groups_mode", "1" if config.ALLOW_GROUPS else "0")
        new = "0" if cur == "1" else "1"
        db.set_setting("groups_mode", new)
        await _settings_menu(q)
    elif data == "adm:inc_limit" or data == "adm:dec_limit":
        cur = int(db.get_setting("daily_limit", str(config.DAILY_LIMIT)))
        cur = cur + 5 if data.endswith("inc_limit") else max(1, cur - 5)
        db.set_setting("daily_limit", str(cur))
        await _settings_menu(q)


async def _settings_menu(q):
    limit = db.get_setting("daily_limit", str(config.DAILY_LIMIT))
    force = "🟢 مفعل" if db.get_setting("force_sub", "1") == "1" else "🔴 معطل"
    groups = "🟢 مفعل" if db.get_setting("groups_mode", "1" if config.ALLOW_GROUPS else "0") == "1" else "🔴 معطل"
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("⬆️ رفع الحد اليومي", callback_data="adm:inc_limit"),
         InlineKeyboardButton("⬇️ خفض الحد اليومي", callback_data="adm:dec_limit")],
        [InlineKeyboardButton(f"🛡️ الاشتراك الإجباري: {force}", callback_data="adm:toggle_force")],
        [InlineKeyboardButton(f"👥 وضع الكروبات: {groups}", callback_data="adm:toggle_groups")],
        [InlineKeyboardButton("💬 تعديل رسالة الترحيب", callback_data="adm:set_welcome")],
        [InlineKeyboardButton("🏷️ تعديل كابشن الفيديو", callback_data="adm:set_caption")],
        [InlineKeyboardButton("↩️ رجوع", callback_data="adm:back")],
    ])
    txt = (f"⚙️ <b>الإعدادات</b>\n\n"
           f"• الحد اليومي لكل مستخدم: <b>{limit}</b> تحميل\n"
           f"• الاشتراك الإجباري: {force}\n"
           f"• وضع الكروبات: {groups}\n"
           f"• عدد المشرفين: {len(_admin_ids())}")
    try:
        await q.message.edit_text(txt, reply_markup=kb, parse_mode=ParseMode.HTML)
    except Exception:
        await q.message.reply_text(txt, reply_markup=kb, parse_mode=ParseMode.HTML)


async def _channels_menu(q):
    chs = db.list_channels()
    lines = [f"• {utils.esc(utils.clip(ch['title'] or ch['username'] or str(ch['chat_id']), 30))} — <code>{ch['chat_id']}</code>"
             for ch in chs] or ["لا توجد قنوات مضافة بعد."]
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("➕ إضافة قناة", callback_data="adm:addchan")],
        [InlineKeyboardButton("➖ حذف قناة", callback_data="adm:delchan")],
        [InlineKeyboardButton("↩️ رجوع", callback_data="adm:back")],
    ])
    await q.message.edit_text(
        "📢 <b>القنوات الإجبارية</b>\n\n" + "\n".join(lines) +
        "\n\n👈 أضف القناة ثم اجعل البوت <b>مشرفاً</b> فيها، ويجب أن تكون القناة <b>عامة</b>.",
        reply_markup=kb, parse_mode=ParseMode.HTML)


# ─── أزرار فرعية ────────────────────────────────────────────
async def sub_cb(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if not is_admin(q.from_user.id):
        return
    data = q.data
    if data == "adm:back":
        await q.message.edit_text("🛠️ <b>لوحة التحكم</b> — اختر عملية:",
                                  reply_markup=keyboards.admin_menu(q.from_user.id),
                                  parse_mode=ParseMode.HTML)
    elif data == "adm:addchan":
        context.user_data["adm_state"] = ST_ADD_CHANNEL
        await q.message.edit_text("➕ أرسل معرف القناة بأحد الصيغ:\n• <code>@username</code>\n• <code>-1001234567890</code>\n• أو <b>حول أي رسالة</b> من القناة.",
                                  parse_mode=ParseMode.HTML)
    elif data == "adm:delchan":
        context.user_data["adm_state"] = ST_DEL_CHANNEL
        await q.message.edit_text("➖ أرسل معرف القناة (<code>-100…</code>) أو @username للحذف.",
                                  parse_mode=ParseMode.HTML)
    elif data == "adm:ban" or data == "adm:unban":
        target = int(context.user_data.get("adm_target", 0))
        if not target:
            await q.message.edit_text("⚠️ لم يُحدد هدف.")
            return
        if data == "adm:ban":
            db.set_field(target, "is_banned", 1)
            await q.message.edit_text(f"⛔ تم حظر <code>{target}</code>.", parse_mode=ParseMode.HTML)
        else:
            db.set_field(target, "is_banned", 0)
            await q.message.edit_text(f"✅ تم رفع الحظر عن <code>{target}</code>.", parse_mode=ParseMode.HTML)
    elif data == "adm:reset_daily":
        target = int(context.user_data.get("adm_target", 0))
        if target:
            db.set_field(target, "daily_count", 0)
            db.set_field(target, "daily_date", "")
            await q.message.edit_text(f"♻️ تم تصفير عداد اليوم للمستخدم <code>{target}</code>.", parse_mode=ParseMode.HTML)
    elif data == "bcast:yes" or data == "bcast:no":
        await _bcast_confirm(update, context)


# ─── البث الجماعي ────────────────────────────────────────────
async def _bcast_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer()
    if q.data == "bcast:no":
        context.user_data.pop("adm_state", None)
        context.user_data.pop("bcast_payload", None)
        await q.message.edit_text("❌ أُلغي البث.")
        return

    payload = context.user_data.pop("bcast_payload", None)
    if not payload:
        await q.message.edit_text("⚠️ لا يوجد محتوى بث.")
        return
    users = db.all_users()
    n = len(users)
    await q.message.edit_text(f"📣 بدء البث إلى <b>{n}</b> مستخدم…", parse_mode=ParseMode.HTML)
    ok = fail = 0
    for i, u in enumerate(users, 1):
        try:
            await _send_payload(context.bot, u["user_id"], payload)
            ok += 1
        except Exception:
            fail += 1
        if i % 50 == 0:
            try:
                await q.message.edit_text(f"📣 جارٍ الإرسال… {i}/{n} (نجح {ok})")
            except Exception:
                pass
        await asyncio.sleep(0.03)
    await q.message.edit_text(utils.tr("ar", "broadcast_done", ok=ok, fail=fail))


async def _send_payload(bot, chat_id: int, payload: dict):
    kind = payload["kind"]
    if kind == "text":
        await bot.send_message(chat_id, payload["text"], parse_mode=ParseMode.HTML,
                               disable_web_page_preview=True)
    elif kind == "photo":
        await bot.send_photo(chat_id, payload["file_id"], caption=payload.get("caption", ""),
                             parse_mode=ParseMode.HTML)
    elif kind == "video":
        await bot.send_video(chat_id, payload["file_id"], caption=payload.get("caption", ""),
                             parse_mode=ParseMode.HTML)
    elif kind == "document":
        await bot.send_document(chat_id, payload["file_id"], caption=payload.get("caption", ""),
                                parse_mode=ParseMode.HTML)
    elif kind == "forward":
        await bot.forward_message(chat_id, payload["from_chat"], payload["message_id"])


# ─── نصوص المشرف (حالات الانتظار) ───────────────────────────
async def admin_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id
    if not is_admin(uid):
        return
    state = context.user_data.get("adm_state")
    msg = update.effective_message
    if not state:
        return
    text = (msg.text or "").strip()

    if state == ST_BROADCAST:
        if msg.photo:
            payload = {"kind": "photo", "file_id": msg.photo[-1].file_id, "caption": msg.caption or ""}
        elif msg.video:
            payload = {"kind": "video", "file_id": msg.video.file_id, "caption": msg.caption or ""}
        elif msg.document:
            payload = {"kind": "document", "file_id": msg.document.file_id, "caption": msg.caption or ""}
        elif msg.forward_origin:
            payload = {"kind": "forward", "from_chat": msg.forward_origin.chat.id if hasattr(msg.forward_origin, "chat") else None,
                       "message_id": None}
            # التوجيه المباشر يحتاج chat_id أصلي — نستخدم الحل البسيط: إعادة إرسال المحتوى
            payload = {"kind": "text", "text": "⚠️ التوجيه غير مدعوم — أرسل رسالة نصية أو وسائط مباشرة."}
        else:
            payload = {"kind": "text", "text": text}
        context.user_data["bcast_payload"] = payload
        kb = InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ تأكيد وإرسال", callback_data="bcast:yes"),
             InlineKeyboardButton("❌ إلغاء", callback_data="bcast:no")]
        ])
        preview = (text if payload["kind"] == "text" else (payload.get("caption") or "🖼️ وسائط"))
        await msg.reply_text(f"📣 <b>معاينة البث:</b>\n\n{utils.clip(preview, 300)}\n\nسيُرسل إلى <b>{db.count_users()}</b> مستخدم.",
                             reply_markup=kb, parse_mode=ParseMode.HTML)

    elif state == ST_ADD_CHANNEL:
        chat_id, title, uname = await _resolve_channel(msg)
        if not chat_id and uname:
            try:
                ch = await context.bot.get_chat("@" + uname.lstrip("@"))
                chat_id, title, uname = ch.id, ch.title or "", ch.username or ""
            except Exception:
                await msg.reply_text("⚠️ لم أجد القناة — تأكد أن @username صحيح، أو أرسل -100xxx، أو حوّل رسالة من القناة. وتأكد أن البوت مشرف فيها.")
                return
        if chat_id:
            db.add_channel(chat_id, title, uname, uid)
            context.user_data.pop("adm_state", None)
            await msg.reply_text(f"✅ أُضيفت القناة <b>{utils.esc(title or uname or str(chat_id))}</b> بنجاح.\n\n"
                                 f"⚠️ مهم: اجعل البوت <b>مشرفاً</b> فيها (بأي صلاحية) حتى يعمل الاشتراك الإجباري.",
                                 parse_mode=ParseMode.HTML)
        else:
            await msg.reply_text("⚠️ لم أتعرف على القناة — أرسل @username أو -100xxx أو حول رسالة من القناة.")

    elif state == ST_DEL_CHANNEL:
        chat_id, title, uname = await _resolve_channel(msg)
        if not chat_id and uname:
            try:
                ch = await context.bot.get_chat("@" + uname.lstrip("@"))
                chat_id = ch.id
            except Exception:
                await msg.reply_text("⚠️ لم أجد القناة.")
                return
        if chat_id:
            db.del_channel(chat_id)
            context.user_data.pop("adm_state", None)
            await msg.reply_text(f"🗑️ حُذفت القناة {utils.esc(title or uname or str(chat_id))}.")
        else:
            await msg.reply_text("⚠️ لم أتعرف على القناة.")

    elif state == ST_FIND_USER:
        await _find_user_reply(context, msg, text, uid)

    elif state == ST_ADD_ADMIN:
        target = await _parse_target(msg, text)
        if target:
            db.add_admin(target, uid)
            context.user_data.pop("adm_state", None)
            await msg.reply_text(f"👑 أصبح <code>{target}</code> مشرفاً الآن.", parse_mode=ParseMode.HTML)
        else:
            await msg.reply_text("⚠️ أرسل ID صحيحاً.")

    elif state == ST_DEL_ADMIN:
        target = await _parse_target(msg, text)
        if target and target in config.ADMIN_IDS:
            await msg.reply_text("⛔ لا يمكن إزالة المشرفين الأساسيين (المعرَّفون في .env).")
        elif target:
            db.del_admin(target)
            context.user_data.pop("adm_state", None)
            await msg.reply_text(f"➖ أُزيلت صلاحيات <code>{target}</code>.", parse_mode=ParseMode.HTML)
        else:
            await msg.reply_text("⚠️ أرسل ID صحيحاً.")

    elif state == ST_SET_WELCOME:
        db.set_setting("welcome", text)
        context.user_data.pop("adm_state", None)
        await msg.reply_text("✅ حُفظت رسالة الترحيب الجديدة.")

    elif state == ST_SET_CAPTION:
        db.set_setting("caption", text)
        context.user_data.pop("adm_state", None)
        await msg.reply_text("✅ حُفظ الكابشن الجديد. (أرسل «-» لإلغائه)")


async def _resolve_channel(msg):
    """يستخرج القناة من النص أو من الرسالة المحوَّلة."""
    text = (msg.text or msg.caption or "").strip()
    ch = _origin_chat(msg)
    if ch is not None:
        return ch.id, ch.title or "", ch.username or ""
    t = text.strip()
    if t.startswith("@"):
        return None, "", t[1:]  # يُحل إلى معرف عبر bot.get_chat لاحقاً
    if t.startswith("-100") and t[4:].isdigit():
        return int(t), "", ""
    return None, "", ""


def _origin_user(msg):
    """استخراج معرف المُحوِّل من forward_origin (البديل الجديد لـ forward_from في PTB 22+)."""
    try:
        fo = getattr(msg, "forward_origin", None)
        if fo is None:
            return None
        for attr in ("sender_user", "author_user"):
            u = getattr(fo, attr, None)
            if u is not None:
                return getattr(u, "id", None)
        ch = getattr(fo, "chat", None)
        if ch is not None:
            return getattr(ch, "id", None)
    except Exception:
        return None
    return None


def _origin_chat(msg):
    """استخراج القناة المحوَّل منها من forward_origin."""
    try:
        fo = getattr(msg, "forward_origin", None)
        if fo is None:
            return None
        return getattr(fo, "chat", None)
    except Exception:
        return None


async def _parse_target(msg, text):
    ou = _origin_user(msg)
    if ou:
        return ou
    t = (text or "").strip().lstrip("@")
    if t.lstrip("-").isdigit():
        return int(t)
    return None


async def _find_user_reply(context, msg, text, admin_id):
    target = await _parse_target(msg, text)
    if not target:
        target = _origin_user(msg)
    if not target:
        await msg.reply_text("⚠️ لم أجد المستخدم — أرسل ID أو @username أو حول رسالة منه.")
        return
    row = db.get_user(target)
    context.user_data["adm_target"] = target
    if row is None:
        await msg.reply_text(f"ℹ️ المستخدم <code>{target}</code> غير مسجل في قاعدة البيانات بعد.\n"
                             f"(لم يستخدم البوت أو لم يصل إليه البث)",
                             reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("⛔ حظر مسبق", callback_data="adm:ban")]]),
                             parse_mode=ParseMode.HTML)
        return
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("⛔ حظر", callback_data="adm:ban"),
         InlineKeyboardButton("✅ فك الحظر", callback_data="adm:unban")],
        [InlineKeyboardButton("♻️ تصفير العداد اليومي", callback_data="adm:reset_daily")],
    ])
    txt = (f"👤 <b>بيانات المستخدم</b>\n\n"
           f"🆔 <code>{row['user_id']}</code>\n"
           f"🏷️ {utils.esc(row['first_name'])} (@{utils.esc(row['username'] or 'لا يوجد')})\n"
           f"🌐 اللغة: {row['lang']} | ⛔ محظور: {'نعم' if row['is_banned'] else 'لا'}\n"
           f"📅 انضم: {utils.human_time(row['joined_at'])}\n"
           f"🕒 آخر نشاط: {utils.human_time(row['last_active'])}\n"
           f"⬇️ إجمالي التحميلات: {row['total_downloads']}\n"
           f"📥 تحميلات اليوم: {row['daily_count']}\n"
           f"🎁 دُعي بواسطة: {row['referrer_id'] or '—'}")
    await msg.reply_text(txt, reply_markup=kb, parse_mode=ParseMode.HTML)


# ─── أوامر سريعة للمشرف ─────────────────────────────────────
async def user_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id) or not context.args:
        return
    try:
        target = int(context.args[0])
    except ValueError:
        return
    context.user_data["adm_target"] = target
    await _find_user_reply(context, update.effective_message, str(target), update.effective_user.id)


async def status_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not is_admin(update.effective_user.id):
        return
    boot = getattr(context.bot_data, "boot_time", int(time.time()))
    uptime = int(time.time()) - boot
    h, rem = divmod(uptime, 3600)
    m, s = divmod(rem, 60)
    await update.effective_message.reply_text(
        f"🖥️ <b>حالة البوت</b>\n"
        f"⏱️ مدة التشغيل: {h} س {m} د {s} ث\n"
        f"🗄️ قاعدة البيانات: <code>{config.DB_PATH}</code> (SQLite)\n"
        f"🌐 الوضع: {'Webhook' if config.WEBHOOK_URL else 'Polling + Health'}\n"
        f"🎵 FFmpeg: {'متوفر' if downloader_ffmpeg() else 'غير متوفر (صوت MP3 معطل)'}",
        parse_mode=ParseMode.HTML)


def downloader_ffmpeg():
    import shutil
    return shutil.which("ffmpeg") is not None


def register(app):
    app.add_handler(CommandHandler("admin", admin_cmd))
    app.add_handler(CommandHandler("stats", stats_cmd))
    app.add_handler(CommandHandler("status", status_cmd))
    app.add_handler(CommandHandler("user", user_cmd))
    # مهم: المُعالَج الأكثر تخصصاً يُسجَّل أولاً — وإلا ابتلعه معالج القائمة الرئيسية ^adm:
    app.add_handler(CallbackQueryHandler(
        sub_cb, pattern=r"^(adm:back|adm:addchan|adm:delchan|adm:ban|adm:unban|adm:reset_daily|bcast:yes|bcast:no)$"))
    app.add_handler(CallbackQueryHandler(menu_cb, pattern=r"^adm:"))
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, admin_text), group=100)
